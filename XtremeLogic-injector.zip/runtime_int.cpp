#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
// 必须！开启Toolhelp快照API，否则PROCESSENTRY32W未定义
#include <tlhelp32.h>
#include <shlwapi.h>
#include <conio.h>
#include <cstdio>
#include <wchar.h>
#include <cstdarg>
#include <cstring>
#include <winternl.h>
#include "runtime_init.h"

// ========= NT类型定义，全部放在cpp内部，不再污染头文件 =========
typedef struct _CLIENT_ID
{
    HANDLE UniqueProcess;
    HANDLE UniqueThread;
} CLIENT_ID, * PCLIENT_ID;

typedef PVOID PSECURITY_DESCRIPTOR;
typedef LONG NTSTATUS;

// 修复 WINAPI 顺序，解决 C2059 cdecl 语法错误
typedef NTSTATUS(WINAPI* fnRtlCreateUserThread)(
    HANDLE Process,
    PSECURITY_DESCRIPTOR SecurityDescriptor,
    BOOLEAN CreateSuspended,
    ULONG StackZeroBits,
    PVOID StackMaximumSize,
    PVOID StackCommitSize,
    PVOID StartAddress,
    PVOID StartParameter,
    PHANDLE ThreadHandle,
    PCLIENT_ID ClientId
    );

// ================= 全局变量定义 =================
uint64_t     g_securityCookie = 0x2B992DDFA232LL;
uint64_t     g_invertedCookie = 0;
int          g_runtimeInitState = 0;
HANDLE       g_hDevice = INVALID_HANDLE_VALUE;
uint8_t      g_byte_140058E78 = 0;

//反逆向
bool IsBeingDebugged()
{
    BOOL bDebug = FALSE;
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &bDebug);
    return bDebug;
}
void CheckDebugger()
{
	if (IsBeingDebugged())
	{
		MessageBoxW(nullptr, L"检测到非法进程，程序将退出。", L"警告", MB_ICONEXCLAMATION);
		ExitProcess(1);
	}
}

/*
 sub_140008300 打开内核驱动设备 \\.\LtqDevice
*/
bool OpenKernelDriverDevice()
{
    char devNameBuffer[256] = { 0 };
    strcpy_s(devNameBuffer, _countof(devNameBuffer), "\\\\.\\");
    strcat_s(devNameBuffer, _countof(devNameBuffer), "LtqDevice");
	CheckDebugger();
    g_hDevice = CreateFileA(
        devNameBuffer,
        GENERIC_READ | GENERIC_WRITE,
        0,
        nullptr,
        OPEN_EXISTING,
        0,
        nullptr
    );
    CheckDebugger();
    if (g_hDevice == INVALID_HANDLE_VALUE)
    {
        return false;
    }
    return true;
}

/*
  sub_140002630 延迟3秒退出
*/
void AutoExitAfterDelay()
{
    CheckDebugger();
    LogPrintW(L"[*] 注入器将在 3 秒后自动退出...");
    Sleep(3000);
    ExitProcess(0);
}

/*
  sub_140002B90 用户层远程线程注入
*/
bool RemoteThreadInject(DWORD dwProcessId, const wchar_t* lpFileName)
{
    CheckDebugger();
    WCHAR szFullPath[264] = { 0 };
    if (!GetFullPathNameW(lpFileName, _countof(szFullPath), szFullPath, nullptr))
    {
        LogPrintW(L"[X] 无法转换为绝对路径!");
        return false;
    }
    CheckDebugger();

    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
    if (hProcess == nullptr)
    {
        DWORD err = GetLastError();
        LogPrintW(L"[X] 无法打开目标进程 (错误码: %u)", err);
        return false;
    }
    CheckDebugger();

    SIZE_T allocSize = (2 * wcslen(szFullPath)) + 2;
    LPVOID pRemoteMem = VirtualAllocEx(hProcess, nullptr, allocSize, MEM_COMMIT, PAGE_READWRITE);
    if (pRemoteMem == nullptr)
    {
        DWORD err = GetLastError();
        LogPrintW(L"[X] 远程内存分配失败 (错误码: %u)", err);
        CloseHandle(hProcess);
        return false;
    }
    CheckDebugger();

    if (!WriteProcessMemory(hProcess, pRemoteMem, szFullPath, allocSize, nullptr))
    {
        DWORD err = GetLastError();
        LogPrintW(L"[X] 内存写入失败 (错误码: %u)", err);
        VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }
    CheckDebugger();

    HMODULE hKernel32 = GetModuleHandleW(L"kernel32.dll");
    LPTHREAD_START_ROUTINE pLoadLibraryW = (LPTHREAD_START_ROUTINE)GetProcAddress(hKernel32, "LoadLibraryW");
    CheckDebugger();

    HANDLE hRemoteThread = CreateRemoteThread(hProcess, nullptr, 0, pLoadLibraryW, pRemoteMem, 0, nullptr);
    if (hRemoteThread == nullptr)
    {
        HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
        fnRtlCreateUserThread RtlCreateUserThread = (fnRtlCreateUserThread)GetProcAddress(hNtdll, "RtlCreateUserThread");
        if (RtlCreateUserThread != nullptr)
        {
            LogPrintW(L"[*] 正在尝试 RtlCreateUserThread...");
            CLIENT_ID cid{};
            RtlCreateUserThread(hProcess, nullptr, FALSE, 0, 0, 0, pLoadLibraryW, pRemoteMem, &hRemoteThread, &cid);
        }
    }
    CheckDebugger();

    if (hRemoteThread == nullptr)
    {
        DWORD err = GetLastError();
        LogPrintW(L"[X] 创建远程线程失败 (错误码: %u)", err);
        VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }
    CheckDebugger();

    WaitForSingleObject(hRemoteThread, INFINITE);
    DWORD exitCode = 0;
    GetExitCodeThread(hRemoteThread, &exitCode);

    CloseHandle(hRemoteThread);
    VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
    CloseHandle(hProcess);
    CheckDebugger();

    if (exitCode != 0)
    {
        return true;
    }
    LogPrintW(L"[!] 远程线程已运行，但 LoadLibrary 返回 NULL，可能是 DLL 依赖缺失。");
    return false;
}

/*
  sub_1400028B0 内核注入
*/
bool KernelInject(DWORD pid, const wchar_t* dllPath)
{
    CheckDebugger();

    if (g_byte_140058E78 == 0)
    {
        LogPrintW(L"[*] 正在初始化内核注入引擎...");
        if (!OpenKernelDriverDevice())
        {
            LogPrintW(L"[X] 内核引擎安装失败!");
            g_byte_140058E78 = 1;
            return false;
        }
        DWORD bytesReturned = 0;
        if (!DeviceIoControl(g_hDevice, 0x2244C0u, nullptr, 0x38, nullptr, 0, &bytesReturned, nullptr))
        {
            LogPrintW(L"[X] 内核引擎激活失败!");
            g_byte_140058E78 = 1;
            return false;
        }
        LogPrintW(L"[+] 内核注入引擎准备就绪!");
        g_byte_140058E78 = 1;
    }
    CheckDebugger();

    LogPrintW(L"[*] 正在执行内核注入 (PID: %d)...", pid);
    LogPrintW(L"[+] 内核注入成功，模块已加载。");
    return true;
}

/*
  sub_140002EF0 监控进程循环
*/
void MonitorAndInjectTarget(const wchar_t* dllFileName)
{
    CheckDebugger();

    LogPrintW(L"[*] 正在监控，等待 preternatural.exe ...");
    while (true)
    {
        CheckDebugger();
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnap != INVALID_HANDLE_VALUE)
        {
            PROCESSENTRY32W pe32{};
            pe32.dwSize = sizeof(PROCESSENTRY32W);
            if (Process32FirstW(hSnap, &pe32))
            {
                do
                {
                    if (_wcsicmp(pe32.szExeFile, L"preternatural.exe") == 0
                        || _wcsicmp(pe32.szExeFile, L"supernatural.exe") == 0)
                    {
                        DWORD targetPid = pe32.th32ProcessID;
                        LogPrintW(L"\a[!] 发现目标进程: %s (PID: %d)", pe32.szExeFile, targetPid);
                        LogPrintW(L"[*] [阶段1] 正在执行 Windows API 注入...");
                        if (RemoteThreadInject(targetPid, dllFileName))
                        {
                            LogPrintW(L"[+] [成功] Windows API 注入成功，模块已加载。");
                            AutoExitAfterDelay();
                        }
                        LogPrintW(L"[!] [阶段2] Windows API 通道被拦截，正在切换到内核注入...");
                        if (KernelInject(targetPid, dllFileName))
                        {
                            LogPrintW(L"[+] [成功] 内核注入成功，模块已加载。");
                            AutoExitAfterDelay();
                        }
                        LogPrintW(L"[X] [失败] 所有注入通道均已失败。");
                        MessageBoxW(nullptr, L"全部注入方式失败", L"错误", MB_ICONEXCLAMATION);
                        ExitProcess(1);
                    }
                } while (Process32NextW(hSnap, &pe32));
            }
            CloseHandle(hSnap);
        }
        Sleep(1);
    }
}

/*
  sub_140003290 主入口
*/
uint32_t AppMainEntry()
{
    CheckDebugger();

    SetConsoleOutputCP(CP_UTF8);
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, FOREGROUND_GREEN);
    LogPrintW(L"  __  ___                           _                _      ");
    LogPrintW(L"  \\ \\/ / |_ _ __ ___ _ __ ___   ___| |    ___   __ _(_) ___ ");
    LogPrintW(L"   \\  /| __| '__/ _ \\ '_ ` _ \\ / _ \\ |   / _ \\ / _` | |/ __|");
    LogPrintW(L"   /  \\| |_| | |  __/ | | | | |  __/ |__| (_) | (_| | | (__ ");
    LogPrintW(L"  /_/\\_\\\\__|_|  \\___|_| |_| |_|\\___|_____\\___/ \\__, |_|\\___|");
	LogPrintW(L"                                               |___/         ");
    LogPrintW(L"============================================================ ");
    LogPrintW(L"欢迎使用XtremeLogic项目");
    LogPrintW(L"项目目前免费,如果你是付费下载,那么你被骗了.");
    LogPrintW(L"------------------------------------------------------------");
    SetConsoleTextAttribute(hStdOut, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    CheckDebugger();

    HANDLE hToken = nullptr;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
    {
        CheckDebugger();

        LUID luidDebug{};
        if (LookupPrivilegeValueW(nullptr, L"SeDebugPrivilege", &luidDebug))
        {
            TOKEN_PRIVILEGES tp{};
            tp.PrivilegeCount = 1;
            tp.Privileges[0].Luid = luidDebug;
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
            AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), nullptr, nullptr);
        }
        CloseHandle(hToken);
        if (GetLastError() != ERROR_SUCCESS)
        {
            LogPrintW(L"[!] [警告] 权限提升失败，请以管理员身份运行!");
        }
        CheckDebugger();

    }

    WCHAR szSelfPath[520] = { 0 };
    GetModuleFileNameW(nullptr, szSelfPath, _countof(szSelfPath));
    PathRemoveFileSpecW(szSelfPath);
    PathAppendW(szSelfPath, L"XtremeDLL.dll");
    CheckDebugger();

    if (PathFileExistsW(szSelfPath))
    {
        LogPrintW(L"[*] [检测] DLL 路径: %s", szSelfPath);
        MonitorAndInjectTarget(szSelfPath);
    }
    CheckDebugger();

    LogPrintW(L"[X] [错误] 找不到 DLL 文件: %s", szSelfPath);
    LogPrintW(L"[*] 按任意键退出...");
    CheckDebugger();
    _getwch();
    return 1;
}

/*
  日志打印
*/
void LogPrintW(const wchar_t* fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    // 计算缓冲区大小
    int needed = _vscwprintf(fmt, ap);
    if (needed <= 0)
    {
        va_end(ap);
        return;
    }
    wchar_t* buf = new wchar_t[needed + 2];
    _vsnwprintf_s(buf, needed + 1, _TRUNCATE, fmt, ap);
    va_end(ap);

    // 输出到控制台
    DWORD written;
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    WriteConsoleW(hConsole, buf, wcslen(buf), &written, nullptr);
    WriteConsoleW(hConsole, L"\r\n", 2, &written, nullptr);

    delete[] buf;
}


//sub_14000E650 计算Cookie

uintptr_t GetSecurityCookie()
{
    const uint64_t COOKIE_UNINIT = 0x2B992DDFA232LL;
    const uint64_t COOKIE_RETURN_MAGIC = 0x2B992DDFA233LL;

    if (g_securityCookie == COOKIE_UNINIT)
    {
        FILETIME ft{};
        GetSystemTimeAsFileTime(&ft);
        uint64_t seed = *(uint64_t*)&ft;
        seed ^= GetCurrentThreadId();
        seed ^= GetCurrentProcessId();

        LARGE_INTEGER perf{};
        QueryPerformanceCounter(&perf);

        uint64_t newCookie = ((uint64_t)&seed ^ seed ^ perf.QuadPart ^ ((uint64_t)perf.LowPart << 32)) & 0xFFFFFFFFFFFFLL;
        if (newCookie == COOKIE_UNINIT)
            newCookie = COOKIE_RETURN_MAGIC;

        g_securityCookie = newCookie;
        g_invertedCookie = ~newCookie;
        return COOKIE_RETURN_MAGIC;
    }
    else
    {
        g_invertedCookie = ~g_securityCookie;
        return ~g_securityCookie;
    }
}

__declspec(noreturn) void __fastcall RtlFailFast(unsigned int a1)
{
    __fastfail(a1);
}

/*
  CRT初始化
*/
uint64_t CrtInitialize()
{
    return AppMainEntry();
}

/*
  PE原始入口 start
*/
uint64_t start()
{
    GetSecurityCookie();
    return CrtInitialize();
}

// VS调试入口 wmain
int wmain()
{
    return (int)start();
}

#pragma once
#ifndef RUNTIME_INIT_H
#define RUNTIME_INIT_H

// 注意：WIN32_LEAN_AND_MEAN 挪到cpp，不要放h！！
#include <windows.h>
#include <cstdint>
#include <string>

std::string exeID;
std::string dllID;

// 全局变量声明
extern uint64_t     g_securityCookie;
extern uint64_t     g_invertedCookie;
extern int          g_runtimeInitState;
extern HANDLE       g_hDevice;
extern uint8_t      g_byte_140058E78;

// 函数原型
uintptr_t GetSecurityCookie();
uint64_t start();
uint64_t CrtInitialize();

__declspec(noreturn) void __fastcall RtlFailFast(unsigned int a1);

bool OpenKernelDriverDevice();
void AutoExitAfterDelay();
bool RemoteThreadInject(DWORD dwProcessId, const wchar_t* lpFileName);
bool KernelInject(DWORD pid, const wchar_t* dllPath);
void MonitorAndInjectTarget(const wchar_t* dllFileName);
uint32_t AppMainEntry();
void LogPrintW(const wchar_t* fmt, ...);

#endif

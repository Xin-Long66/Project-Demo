#pragma once

#include "XtremeLogic.h"

namespace ProgressBar
{
	void ShowProgressBar(int progress)
	{
		if (progress < 0) progress = 0;
		if (progress > 100) progress = 100;
		if (progress > 0 && progress < 5) progress = 0;
		if (progress > 5 && progress < 10) progress = 5;
		if (progress > 10 && progress < 15) progress = 10;
		if (progress > 15 && progress < 20) progress = 15;
		if (progress > 20 && progress < 25) progress = 20;
		if (progress > 25 && progress < 30) progress = 25;
		if (progress > 30 && progress < 35) progress = 30;
		if (progress > 35 && progress < 40) progress = 35;
		if (progress > 40 && progress < 45) progress = 40;
		if (progress > 45 && progress < 50) progress = 45;
		if (progress > 50 && progress < 55) progress = 50;
		if (progress > 55 && progress < 60) progress = 55;
		if (progress > 60 && progress < 65) progress = 60;
		if (progress > 65 && progress < 70) progress = 65;
		if (progress > 70 && progress < 75) progress = 70;
		if (progress > 75 && progress < 80) progress = 75;
		if (progress > 80 && progress < 85) progress = 80;
		if (progress > 85 && progress < 90) progress = 85;
		if (progress > 90 && progress < 95) progress = 90;
		if (progress > 95 && progress < 100) progress = 95;



		if (progress == 0)
		{
			std::cout << "⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-0%\r";
		}
		else if (progress == 5)
		{
			std::cout << "●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-5%\r";
		}
		else if (progress == 10)
		{
			std::cout << "●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-10%\r";
		}
		else if (progress == 15)
		{
			std::cout << "●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-15%\r";
		}
		else if (progress == 20)
		{
			std::cout << "●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-20%\r";
		}
		else if (progress == 25)
		{
			std::cout << "●●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-25%\r";
		}
		else if (progress == 30)
		{
			std::cout << "●●●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-30%\r";
		}
		else if (progress == 35)
		{
			std::cout << "●●●●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-35%\r";
		}
		else if (progress == 40)
		{
			std::cout << "●●●●●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-40%\r";
		}
		else if (progress == 45)
		{
			std::cout << "●●●●●●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-45%\r";
		}
		else if (progress == 50)
		{
			std::cout << "●●●●●●●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜-50%\r";
		}
		else if (progress == 55)
		{
			std::cout << "●●●●●●●●●●●⬜⬜⬜⬜⬜⬜⬜⬜⬜-55%\r";
		}
		else if (progress == 60)
		{
			std::cout << "●●●●●●●●●●●●⬜⬜⬜⬜⬜⬜⬜⬜-60%\r";
		}
		else if (progress == 65)
		{
			std::cout << "●●●●●●●●●●●●●⬜⬜⬜⬜⬜⬜⬜-65%\r";
		}
		else if (progress == 70)
		{
			std::cout << "●●●●●●●●●●●●●●⬜⬜⬜⬜⬜⬜-70%\r";
		}
		else if (progress == 75)
		{
			std::cout << "●●●●●●●●●●●●●●●⬜⬜⬜⬜⬜-75%\r";
		}
		else if (progress == 80)
		{
			std::cout << "●●●●●●●●●●●●●●●●⬜⬜⬜⬜-80%\r";
		}
		else if (progress == 85)
		{
			std::cout << "●●●●●●●●●●●●●●●●●⬜⬜⬜-85%\r";
		}
		else if (progress == 90)
		{
			std::cout << "●●●●●●●●●●●●●●●●●●⬜⬜-90%\r";
		}
		else if (progress == 95)
		{
			std::cout << "●●●●●●●●●●●●●●●●●●●⬜-95%\r";
		}
		else if (progress == 100)
		{
			std::cout << "●●●●●●●●●●●●●●●●●●●●-100%[已完成]\n";
		}
	}
	void PBDemo()
	{
		std::cout << "进度：25  -ProgressBar::ShowProgressBar(25);" << std::endl;
		ProgressBar::ShowProgressBar(25);
	}
	void PBDemo2()
	{
		ProgressBar::ShowProgressBar(25);
		Sleep(20000);
		ProgressBar::ShowProgressBar(55);
		Sleep(20000);
		ProgressBar::ShowProgressBar(100);
	}
}
#pragma once

#include "XtremeLogic.h"

namespace XtremeStyle
{
    void pinkStyle()
    {
        ImGuiStyle& style = ImGui::GetStyle();

        style.WindowRounding = 8.0f;
        style.ChildRounding = 4.0f;
        style.FrameRounding = 3.0f;
        style.PopupRounding = 4.0f;
        style.ScrollbarRounding = 6.0f;
        style.GrabRounding = 3.0f;
        style.TabRounding = 4.0f;

        ImVec4* colors = style.Colors;
        // ========== 基础底色 ==========
        colors[ImGuiCol_Text] = ImVec4(0.95f, 0.95f, 0.95f, 1.00f);
        colors[ImGuiCol_TextDisabled] = ImVec4(0.45f, 0.45f, 0.47f, 1.00f);
        colors[ImGuiCol_WindowBg] = ImVec4(26.f / 255, 26.f / 255, 29.f / 255, 0.85f);
        colors[ImGuiCol_ChildBg] = ImVec4(22.f / 255, 22.f / 255, 25.f / 255, 1.00f);
        colors[ImGuiCol_PopupBg] = ImVec4(22.f / 255, 22.f / 255, 25.f / 255, 1.00f);
        colors[ImGuiCol_Border] = ImVec4(0.30f, 0.30f, 0.33f, 0.60f);
        colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);

        // ========== 输入框、Frame控件背景 ==========
        colors[ImGuiCol_FrameBg] = ImVec4(34.f / 255, 34.f / 255, 38.f / 255, 1.00f);
        colors[ImGuiCol_FrameBgHovered] = ImVec4(60.f / 255, 35.f / 255, 48.f / 255, 1.00f);
        colors[ImGuiCol_FrameBgActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.45f);

        // ========== 标题栏（你的主色RGB 230,57,124） ==========
        colors[ImGuiCol_TitleBg] = ImVec4(180.f / 255, 40.f / 255, 98.f / 255, 1.00f);
        colors[ImGuiCol_TitleBgActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);
        colors[ImGuiCol_TitleBgCollapsed] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.40f);

        colors[ImGuiCol_MenuBarBg] = ImVec4(30.f / 255, 30.f / 255, 33.f / 255, 1.00f);

        // ========== 滚动条 ==========
        colors[ImGuiCol_ScrollbarBg] = ImVec4(20.f / 255, 20.f / 255, 23.f / 255, 1.00f);
        colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.32f, 0.32f, 0.35f, 1.00f);
        colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.70f);
        colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);

        // ========== 勾选框、滑块 ==========
        colors[ImGuiCol_CheckMark] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);
        colors[ImGuiCol_SliderGrab] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.75f);
        colors[ImGuiCol_SliderGrabActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);

        // ========== 按钮 ==========
        colors[ImGuiCol_Button] = ImVec4(40.f / 255, 40.f / 255, 44.f / 255, 1.00f);
        colors[ImGuiCol_ButtonHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.65f);
        colors[ImGuiCol_ButtonActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);

        // ========== TreeNode / Header折叠栏 ==========
        colors[ImGuiCol_Header] = ImVec4(38.f / 255, 38.f / 255, 42.f / 255, 1.00f);
        colors[ImGuiCol_HeaderHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.55f);
        colors[ImGuiCol_HeaderActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.80f);

        //========== 分割线 ==========
        colors[ImGuiCol_Separator] = ImVec4(0.30f, 0.30f, 0.33f, 0.60f);
        colors[ImGuiCol_SeparatorHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.70f);
        colors[ImGuiCol_SeparatorActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);

        // ========== 窗口缩放抓手 ==========
        colors[ImGuiCol_ResizeGrip] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.25f);
        colors[ImGuiCol_ResizeGripHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.65f);
        colors[ImGuiCol_ResizeGripActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);

        // ========== Tab标签页 ==========
        colors[ImGuiCol_Tab] = ImVec4(32.f / 255, 32.f / 255, 36.f / 255, 1.00f);
        colors[ImGuiCol_TabHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.60f);
        colors[ImGuiCol_TabActive] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.90f);
        colors[ImGuiCol_TabUnfocused] = ImVec4(28.f / 255, 28.f / 255, 31.f / 255, 1.00f);
        colors[ImGuiCol_TabUnfocusedActive] = ImVec4(45.f / 255, 30.f / 255, 38.f / 255, 1.00f);

        // ========== 图表Plot ==========
        colors[ImGuiCol_PlotLines] = ImVec4(0.70f, 0.70f, 0.72f, 1.00f);
        colors[ImGuiCol_PlotLinesHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);
        colors[ImGuiCol_PlotHistogram] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.70f);
        colors[ImGuiCol_PlotHistogramHovered] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);

        // ========== 表格 ==========
        colors[ImGuiCol_TableHeaderBg] = ImVec4(34.f / 255, 34.f / 255, 38.f / 255, 1.00f);
        colors[ImGuiCol_TableBorderStrong] = ImVec4(0.34f, 0.34f, 0.37f, 1.00f);
        colors[ImGuiCol_TableBorderLight] = ImVec4(0.26f, 0.26f, 0.29f, 1.00f);
        colors[ImGuiCol_TableRowBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
        colors[ImGuiCol_TableRowBgAlt] = ImVec4(1.00f, 1.00f, 1.00f, 0.04f);

        // ========== 选中文本、拖拽、导航 ==========
        colors[ImGuiCol_TextSelectedBg] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.45f);
        colors[ImGuiCol_DragDropTarget] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 0.90f);
        colors[ImGuiCol_NavHighlight] = ImVec4(230.f / 255, 57.f / 255, 124.f / 255, 1.00f);
        colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
        colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.20f);
        colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.75f);
    }
}
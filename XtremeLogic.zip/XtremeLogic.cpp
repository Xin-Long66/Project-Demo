
#include "All.h"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	// 申请控制台输出
    CreateLogConsole();
    // 检测权限，非管理员直接重启提权
    if (!IsRunAsAdmin())
    {
         if (RestartAsAdmin())
         {
            // 启动管理员版本后，关闭当前低权限进程

             return 0;
         }
         else
         {
             std::cout << "获取管理员权限失败，请右键[以管理员身份运行]！" << std::endl;
             return -1;
         }
    }
	std::cout << "已获取终端最高级权限！" << std::endl;

	ProgressBar::PBDemo2();

}
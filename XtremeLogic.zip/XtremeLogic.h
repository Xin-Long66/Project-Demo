#pragma once

#define NOMINMAX

//外联项目头文件

#include <windows.h>
#include <iostream>
#include <TlHelp32.h>
#include <tchar.h>

#include "imgui/imgui.h"
#include "imgui/imgui_impl_win32.h"
#include "imgui/imgui_impl_dx12.h"

#include "d3d12.h"
#include "dxgi1_4.h"
#include "d3dcompiler.h"

#ifdef _DEBUG
#include <dxgidebug.h>
#include <d3d12sdklayers.h>
#endif // _DEBUG

#pragma comment(lib, "d3d12.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")









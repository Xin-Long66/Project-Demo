#pragma once

#include "XtremeLogic.h"


static void HelpMarker(const char* desc)
{
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered())
    {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }

}


namespace XGUI
{
    void BeginGUI()
    {
        //===============绘制开始

        ImGui::SetNextWindowPos(ImVec2(40, 40), ImGuiCond_Once);  //设置窗口位置(ImVec2(x,y))
        ImGui::SetNextWindowSize(ImVec2(400, 200), ImGuiCond_Once); //设置窗口大小(ImVec2(宽,高))
        ImGui::Begin("XtremeLogic | Insert显/隐");      //绘制开始
        ImGui::Text("欢迎使用XtremeLogic!");    //显示文本
        //static char Strtext[MAX_PATH] = "";
        //static char Strtext2[MAX_PATH] = "";
        //ImGui::InputText("TEXT", Strtext, MAX_PATH);
        //ImGui::InputText("PASS", Strtext2, MAX_PATH, ImGuiInputTextFlags_Password);
        //ImGui::Text("TEXT:%s", Strtext);
        //ImGui::Text("PASS:%s", Strtext2);
        ImGui::SameLine();
        if (ImGui::Button("安全退出")) {
            MessageBox(NULL, _T("辅助已退出!"), _T("提示"), NULL);
            ExitProcess(0);
        }

        static bool night_version = false;
        static bool ViewMAX = false;
        static FLOAT VIEWUP = 89.999;
        static FLOAT VIEWDOWN = -89.999;
        static FLOAT brightness = 7.500;

        //ImGui::Separator();//分割线
        if (ImGui::BeginTabBar("菜单"))
        {
            if (ImGui::BeginTabItem("主页"))
            {
                ImGui::Text("版本：");
                ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Text, (ImVec4(1.000f, 0.000f, 0.000f, 1.000f)));
                ImGui::Text("Alpha 0.1");
                ImGui::PopStyleColor();

                ImGui::Text("构建者：");
                ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Text, (ImVec4(0.884f, 0.779f, 0.122f, 1.000f)));
                ImGui::Text("xinlong");
                ImGui::PopStyleColor();
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("内存功能"))
            {
                if (ImGui::CollapsingHeader("内存功能"))
                {
                    ImGui::Checkbox("高亮夜视", &night_version);
                    ImGui::SameLine();
                    HelpMarker("妈妈再也不怕我天黑看不清了!");
                    if (night_version) {
                        ImGui::SliderFloat("亮度", &brightness, 1, 15);
                        ImGui::SameLine();
                        HelpMarker("你眼睛有多好使");
                    }

                    ImGui::Separator();//分割线

                    ImGui::Checkbox("解除视野限制", &ViewMAX);
                    ImGui::SameLine();
                    HelpMarker("脚底开枪这一块");
                    if (ViewMAX) {
                        if (ImGui::TreeNode("角度设定")) {
                            ImGui::SliderFloat("仰角", &VIEWUP, 0, +90);
                            ImGui::SameLine();
                            HelpMarker("抬头看天");
                            ImGui::SliderFloat("俯角", &VIEWDOWN, 0, -90);
                            ImGui::SameLine();
                            HelpMarker("低头看脚下");

                            ImGui::TreePop();
                        }
                    }
                }
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("绘制功能"))
            {
                if (ImGui::CollapsingHeader("绘制功能"))
                {
                    ImGui::Text("暂无功能");
                    ImGui::SameLine();
                    HelpMarker("敬请期待");
                }
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("自瞄功能"))
            {
                if (ImGui::CollapsingHeader("自瞄功能"))
                {
                    ImGui::Text("暂无功能");
                    ImGui::SameLine();
                    HelpMarker("敬请期待");
                }
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
        ImGui::End();




        ImGui::Render();

        //======================
    }
}

#pragma once
#include "XtremeLogic.h"


// 初始化控制台窗口
void CreateLogConsole()
{
    AllocConsole();
    FILE* pFile;
    // 绑定标准输出、标准错误到控制台
    freopen_s(&pFile, "CONOUT$", "w", stdout);
    freopen_s(&pFile, "CONOUT$", "w", stderr);
    SetConsoleTitleW(L"XtremeLogic控制台");
    system("chcp 65001 > nul");
}


// 判断当前程序是否拥有管理员权限
bool IsRunAsAdmin()
{
    BOOL isAdmin = FALSE;
    HANDLE hToken = nullptr;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
    {
        TOKEN_ELEVATION elevation;
        DWORD cbSize = sizeof(TOKEN_ELEVATION);
        if (GetTokenInformation(hToken, TokenElevation, &elevation, cbSize, &cbSize))
        {
            isAdmin = elevation.TokenIsElevated;
        }
        CloseHandle(hToken);
    }
    return isAdmin != FALSE;
}

// 重启程序并请求管理员权限
bool RestartAsAdmin()
{
    WCHAR szExePath[MAX_PATH] = { 0 };
    GetModuleFileNameW(NULL, szExePath, MAX_PATH);

    SHELLEXECUTEINFOW sei = { sizeof(SHELLEXECUTEINFOW) };
    sei.lpVerb = L"runas";        // 核心：请求管理员运行
    sei.lpFile = szExePath;
    sei.nShow = SW_SHOW;
    return ShellExecuteExW(&sei);

}


template<typename T>
T ReadMemory(HANDLE hProcess, uintptr_t Address)
{
    T buffer{};
    ReadProcessMemory(hProcess, (LPCVOID)Address, &buffer, sizeof(T), nullptr);
    return buffer;
}

template<typename T>
BOOL WriteMemory(HANDLE hProcess, uintptr_t Address, T Value)
{
    return WriteProcessMemory(hProcess, (LPVOID)Address, &Value, sizeof(T), nullptr);
}
// ============================================

// 你的全局变量、其他函数写在这下面
HANDLE hProcess = nullptr;

// 通过进程名获取PID（你原有函数）
DWORD GetProcessIdByName(const wchar_t* ProcessName)
{
    DWORD pid = 0;
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap != INVALID_HANDLE_VALUE)
    {
        PROCESSENTRY32 pe32;
        pe32.dwSize = sizeof(PROCESSENTRY32);
        if (Process32First(hSnap, &pe32))
        {
            do
            {
                if (_wcsicmp(pe32.szExeFile, ProcessName) == 0)
                {
                    pid = pe32.th32ProcessID;
                    break;
                }
            } while (Process32Next(hSnap, &pe32));
        }
    }
    CloseHandle(hSnap);
    return pid;
}

// 循环等待目标进程，返回PID
DWORD WaitProcessGetPID(const wchar_t* TargetExeName, DWORD CheckIntervalMs = 500)
{
    DWORD targetPid = 0;
    while (true)
    {
        targetPid = GetProcessIdByName(TargetExeName);
        if (targetPid != 0)
        {
            std::cout << "成功找到进程！" << targetPid << std::endl;
			std::cout << "进程序列号: " << targetPid << std::endl;
            break;
        }

        Sleep(CheckIntervalMs);
    }
    return targetPid;
}

void CopyHello()
{
    
    printf("初始化完成\n");
    std::cout << "  __  ___                           _                _      " << std::endl;
    std::cout << "  \\ \\/ / |_ _ __ ___ _ __ ___   ___| |    ___   __ _(_) ___ " << std::endl;
    std::cout << "   \\  /| __| '__/ _ \\ '_ ` _ \\ / _ \\ |   / _ \\ / _` | |/ __|" << std::endl;
    std::cout << "   /  \\| |_| | |  __/ | | | | |  __/ |__| (_) | (_| | | (__ " << std::endl;
    std::cout << "  /_/\\_\\\\__|_|  \\___|_| |_| |_|\\___|_____\\___/ \\__, |_|\\___|" << std::endl;
    std::cout << "                                               |___/        " << std::endl;
    std::cout << "============================================================" << std::endl;
    std::cout << "欢迎使用XtremeLogic项目" << std::endl;
    std::cout << "项目目前免费,如果你是付费下载,那么你被骗了." << std::endl;
    std::cout << "------------------------------------------------------------" << std::endl;



}


//// 申请控制台输出
//CreateLogConsole();
//// 检测权限，非管理员直接重启提权
//if (!IsRunAsAdmin())
//{
//    if (RestartAsAdmin())
//    {
//        // 启动管理员版本后，关闭当前低权限进程
//
//        return 0;
//    }
//    else
//    {
//        std::cout << "获取管理员权限失败，请右键[以管理员身份运行]！" << std::endl;
//        return -1;
//    }
//}

//std::cout << "正在检测游戏运行状态" << std::endl;
//
//// 循环检测 preternatural.exe
//DWORD pid = WaitProcessGetPID(L"preternatural.exe");
//
//// 拿到PID后，后续OpenProcess读写内存等操作
//HANDLE hProcess = OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION, FALSE, pid);
//if (hProcess == nullptr)
//{
//    std::cout << "OpenProcess 远控进程失败" << std::endl;
//    return -1;
//}
//
//CloseHandle(hProcess);
// 
// 
//std::cout << "正在拉起悬浮窗口" << std::endl;
